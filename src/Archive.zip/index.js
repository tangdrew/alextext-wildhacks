MessagingSkill = require('./MessagingSkill');
API = require('./API');

console.log('Loading function');

var AWS = require('aws-sdk');
var dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = function(event, context, callback) {

    if(event.request == null) {
        console.log('HTTP Request');

        API(event, context, callback);
        // var operation = event.operation;

        // if (event.tableName) {
        //     event.payload.TableName = event.tableName;
        // }

        // switch (operation) {
        //     case 'create':
        //         dynamo.put(event.payload, callback);
        //         break;
        //     case 'read':
        //         dynamo.get(event.payload, callback);
        //         break;
        //     case 'update':
        //         dynamo.update(event.payload, callback);
        //         break;
        //     case 'delete':
        //         dynamo.delete(event.payload, callback);
        //         break;
        //     case 'list':
        //         dynamo.scan(event.payload, callback);
        //         break;
        //     case 'echo':
        //         callback(null, "Success");
        //         break;
        //     case 'ping':
        //         callback(null, "pong");
        //         break;
        //     default:
        //         callback('Unknown operation: ${operation}');
        // }
    }
    else {
        var skill = new MessagingSkill();
        skill.execute(event, context);
    }
    
};